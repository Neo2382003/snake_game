var Load = {
  preload: function() {
    var loadingLabel = game.add.text(game.world.centerX, 150, 'Loading!', { font: '28px Sans Comic', fill: '#ffffff' });
    loadingLabel.anchor.setTo(0.5, 0,5);
    
    var progressBar = game.add.sprite(game.world.centerX, 200, 'progressBar');
    progressBar.anchor.setTo(0.5, 0.5);
    game.load.setPreloadSprite(progressBar);
    
	
	// test 
	game.load.image('snake', './images/snake.png');
        game.load.image('apple', './images/apple.png');
		
		// här kommer knapparna
		game.load.image('upButton', './images/uparrow.png?' + Date.now());
		game.load.image('rightButton', './images/rightarrow.png?' + Date.now());
		game.load.image('downButton', './images/downarrow.png?' + Date.now());
		game.load.image('leftButton', './images/leftarrow.png?' + Date.now());
		//game.load.audio('eat', './assets/sounds/boop2.ogg?' + Date.now());
		// hit = gameOver
		
		
    
  },
  
  create: function() {
	  game.stage.backgroundColor = '#061ffff';
	  console.log("foobar");
	  
    game.state.start('Menu');
  }
};